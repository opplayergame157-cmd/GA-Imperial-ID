package com.gaflow.imperialid

import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var privatePanel: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 9, 9)
        window.navigationBarColor = Color.rgb(9, 9, 9)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(9, 9, 9))
        }

        val emblem = TextView(this).apply {
            text = "GA"
            textSize = 52f
            setTextColor(Color.rgb(255, 48, 48))
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(emblem, matchWrap())

        val title = TextView(this).apply {
            text = "IMPERIAL ID"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "AUTENTICAÇÃO DO DISPOSITIVO"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        root.addView(subtitle, matchWrap())

        val authenticate = Button(this).apply {
            text = "AUTENTICAR COM BIOMETRIA"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(170, 20, 30))
            setOnClickListener { authenticateUser() }
        }
        root.addView(authenticate, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 18 })

        status = TextView(this).apply {
            text = "Painel bloqueado. Autentique-se para continuar."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 20)
        }
        root.addView(status, matchWrap())

        privatePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(28, 14, 16))
            visibility = View.GONE
        }
        val panelTitle = TextView(this).apply {
            text = "ACESSO AUTORIZADO"
            textSize = 20f
            setTextColor(Color.rgb(255, 70, 70))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val panelBody = TextView(this).apply {
            text = "Bem-vindo ao painel privado do GA Imperial ID.\\n\\nEsta é a base inicial do aplicativo."
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 0)
        }
        privatePanel.addView(panelTitle, matchWrap())
        privatePanel.addView(panelBody, matchWrap())
        root.addView(privatePanel, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        setContentView(root)
    }

    private fun authenticateUser() {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL

        when (manager.canAuthenticate(authenticators)) {
            BiometricManager.BIOMETRIC_SUCCESS -> showBiometricPrompt(authenticators)
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                status.text = "Nenhuma biometria ou bloqueio de tela configurado. Configure nas Configurações do Android."
            }
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
                status.text = "Este dispositivo não oferece hardware biométrico compatível. Verifique se o bloqueio de tela está configurado."
            }
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> {
                status.text = "A autenticação está temporariamente indisponível. Tente novamente."
            }
            else -> {
                status.text = "Não foi possível iniciar a autenticação. Confira o bloqueio de tela e tente novamente."
            }
        }
    }

    private fun showBiometricPrompt(authenticators: Int) {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    status.text = "Identidade confirmada pelo Android."
                    privatePanel.visibility = View.VISIBLE
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    status.text = "Não reconhecido. Tente novamente."
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    status.text = "Autenticação cancelada ou indisponível: $errString"
                }
            })

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("GA Imperial ID")
            .setSubtitle("Confirme sua identidade para abrir o painel")
            .setAllowedAuthenticators(authenticators)
            .build()

        prompt.authenticate(info)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
